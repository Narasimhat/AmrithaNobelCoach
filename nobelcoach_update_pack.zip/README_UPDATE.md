
# Nobel Coach — Upgrade Pack
This pack helps you apply the UX/AI upgrades we discussed to your existing Streamlit app.

## Files included
- `styles.css` — polished styles (cards, chips, primary button).
- `recommender.py` — rule-based adaptive engine that suggests next actions.
- `curiosity_tree.py` — simple Curiosity Tree progress (swap for SVG later).

## How to install
1. Copy these files into your app root (same folder as `app.py`).
2. In `app.py` (top, after imports), add:
   ```python
   import streamlit as st
   from curiosity_tree import render_curiosity_tree
   st.markdown('<style>' + open('styles.css').read() + '</style>', unsafe_allow_html=True)
   ```

3. On **Home** (or your main header area), render the Curiosity Tree:
   ```python
   from db_utils import total_points, streak_days, count
   render_curiosity_tree(points=total_points(), streak=streak_days(), missions=count('missions'))
   ```

4. Replace Coach mode dropdown with **mode chips** (conceptual example):
   ```python
   if 'mode' not in st.session_state:
       st.session_state['mode'] = 'Spark'
   cols = st.columns(5)
   modes = [('💡','Spark'),('🔧','Build'),('🧠','Think'),('✍️','Write'),('🎤','Share')]
   for i,(icon,label) in enumerate(modes):
       if cols[i].button(f"{icon} {label}", key=f"chip_{label}"):
           st.session_state['mode'] = label
   st.write("Current mode:", st.session_state['mode'])
   ```

5. Wire the **recommender** where you show suggestions (Home or Parents page):
   ```python
   from recommender import recommend
   profile = {
       'tags_counts': {'Planet': 4, 'Build': 3, 'Think': 2},  # TODO: compute from your DB
       'streak': streak_days(),
       'recent_idle_days': 0,
       'last_completed_tags': []
   }
   for s in recommend(profile):
       st.info(f"🧭 Suggested • {s['type']} → {s['id']} — {s['reason']}")
   ```
